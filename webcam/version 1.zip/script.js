async function startWebcam() {
  const videoEl = document.getElementById('camera');
  const statusEl = document.getElementById('status');

  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    statusEl.textContent = 'Camera access is not supported in this browser.';
    return;
  }

  try {
    // Request the user's webcam. "user" prefers the front-facing camera on devices that have it.
    const constraints = {
      video: {
        width: { ideal: 1920 },
        facingMode: 'user'
      },
      audio: false
    };

    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    videoEl.srcObject = stream;
    statusEl.textContent = '';
  } catch (err) {
    console.error(err);
    statusEl.textContent = `Unable to access the camera: ${err.name || 'Error'}`;
  }
}

function setupRotateControl() {
  const videoEl = document.getElementById('camera');
  const btn = document.getElementById('rotateBtn');
  if (!videoEl || !btn) return;

  let rotated = false;
  btn.addEventListener('click', () => {
    rotated = !rotated;
    videoEl.style.transformOrigin = 'center center';
    videoEl.style.transform = rotated ? 'rotate(180deg)' : 'none';
    btn.textContent = rotated ? 'Reset Rotation' : 'Rotate 180°';
    btn.setAttribute('aria-pressed', String(rotated));
  });
}

window.addEventListener('DOMContentLoaded', () => {
  startWebcam();
  setupRotateControl();
});
